// Left recursion elimination
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

char* retStr(char* token,int start) {
	if(start == 1) {
		char str[10];
		int i;
		for(i=1; i<strlen(token); i++) {
			str[i-1] = token[i];
		}
		str[i-1] = '\0';
		sprintf(token, "%s",str);
		return token;
	}
	else {
		return token;
	}
} 

char* convertProd(char* input) {
	char prod1[15] = "", prod2[15] = "";
	char* token = strtok(input,"=");
	char lhs[10];
	strcpy(lhs,token);
	sprintf(prod1, "%s=", token);
	sprintf(prod2, "%s'=", token);
	while (token != NULL) {
		token = strtok(NULL, "|");
		if(token != NULL) {
			if(lhs[0] == token[0]) {
				token = retStr(token, 1);
				sprintf(prod2, "%s%s%s'|", prod2, token, lhs);
			}
			else {
				token = retStr(token, 0);
				sprintf(prod1, "%s%s%s'|", prod1, token, lhs);
			}
		}
	}
	int len = strlen(prod1);
	prod1[len-1] = '\n';
	strcat(prod2,"e");

	strcat(prod1, prod2);
	strcpy(input, prod1);
	return input;
}

int checkProd(char* input) {
	char* token = strtok(input,"=");
	char lhs = token[0];
	while (token != NULL) {
		token = strtok(NULL, "|");
		if(token != NULL) {
			if(lhs == token[0]) {
				return 1;
			}
		}
	}
	return 0;
}

int main(int argc, char* argv[]) {

	int n,i,j;
	char temp[15];
	printf("\nNumber of productions: ");
	scanf("%d",&n);
	char **input = (char **)malloc(n * sizeof(char *));
	for(i=0;i<n;i++) {
		input[i] = (char *)malloc(30 * sizeof(char));
	}
	i = 0;
	j = n;
	printf("\nInput all productions: (max 15 characters each)");
	printf("\n(NOTE: use '=' instead of '->' for rule specification)\n");
	while(j--) { // get input productions
		scanf("%s",input[i++]);
	}
	for(i=0;i<n;i++) {
		strcpy(temp, input[i]);
		int flag = checkProd(temp);
		if(flag==0) {
			printf("\n%s",input[i]);
			printf("\nNo Left recursions\n");
			continue;
		}
		else {
			printf("\n%s",input[i]);
			printf("\nLeft recursion exists\n");
			input[i] = convertProd(input[i]);
			printf("New productions:");
			printf("\n%s", input[i]);
			printf("\n(Note 'e' denotes epsilon)\n");
		}
	}
	return 0;
}
