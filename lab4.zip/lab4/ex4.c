#include<stdio.h>
#include<string.h>
#include<stdlib.h>

int flag, pos;
char input[15];

void E();

void F() {
	printf("\t\t\tF()\n");
	if(input[pos]=='('){
		pos++;
		E();
		if(input[pos]==')'){
			pos++;
		}
	}
	else if(input[pos]=='i')
		pos++;
	else {
		flag=1;
	}
}

void T_() {
	printf("\t\t\tT'()\n");
	if(input[pos] == '*') {
		pos++;
		F();
		T_();
	}
}

void T() {
	printf("\t\tT()\n");
	F();
	T_();
}

void E_() {
	printf("\t\tE'()\n");
	if(input[pos] == '+') {
		pos++;
		T();
		E_();
	}
}

void E() {
	printf("\tE()\n");
	T();
	E_();
}

int main(int argc, char* argv[]) {

	printf("Given grammar:\nE->TE'\nE'->+TE'|e");
	printf("\nT->FT'\nT'->*FT'|e\nF->id|(E)\n");
	printf("\nInput String (max 15 characters) :\n");
	printf("(Use 'i' instead of 'id') :\n");
	scanf("%s",input);
	pos = 0; flag = 0;
	
	E();
	if(flag == 0) {
		printf("\nString Accepted\n");
	}
	else {
		printf("\nInvalid string\n");
	}
	return 0;
}
