int a=9, b1, number=10;
float f1=4.5, f2=6E2;
float f3=4E+9;
char c=’a’;
